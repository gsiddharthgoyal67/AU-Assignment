package com.customApiScheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomApiSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
