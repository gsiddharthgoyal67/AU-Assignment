package com.customApiScheduler.service;


import com.customApiScheduler.model.ApiConfig;
import com.customApiScheduler.repository.ApiConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApiSchedulerService {
    private final ApiConfigRepository apiConfigRepository;
    private final ApiExecutionService apiExecutionService;

    @Scheduled(fixedRate = 60000) // Run every minute
    @Transactional
    public void executeScheduledApis() {
        log.info("Checking for APIs due for execution");
        List<ApiConfig> dueApis = apiConfigRepository.findApisDueForExecution(LocalDateTime.now());

        for (ApiConfig apiConfig : dueApis) {
            try {
                apiExecutionService.executeApi(apiConfig);
                updateNextExecutionTime(apiConfig);
            } catch (Exception e) {
                log.error("Error executing API {}: {}", apiConfig.getName(), e.getMessage());
            }
        }
    }

    @Transactional
    public ApiConfig createApiConfig(ApiConfig apiConfig) {
        validateApiConfig(apiConfig);
        apiConfig.setNextExecutionTime(LocalDateTime.now());
        return apiConfigRepository.save(apiConfig);
    }

    @Transactional
    public ApiConfig updateApiConfig(Long id, ApiConfig updatedConfig) {
        return apiConfigRepository.findById(id)
                .map(existing -> {
                    existing.setName(updatedConfig.getName());
                    existing.setUrl(updatedConfig.getUrl());
                    existing.setHttpMethod(updatedConfig.getHttpMethod());
                    existing.setScheduleInterval(updatedConfig.getScheduleInterval());
                    existing.setRequestHeaders(updatedConfig.getRequestHeaders());
                    existing.setRequestBody(updatedConfig.getRequestBody());
                    existing.setActive(updatedConfig.isActive());
                    return apiConfigRepository.save(existing);
                })
                .orElseThrow(() -> new RuntimeException("API Config not found"));
    }

    @Transactional
    public void deleteApiConfig(Long id) {
        apiConfigRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<ApiConfig> getAllApiConfigs() {
        return apiConfigRepository.findAll();
    }

    @Transactional(readOnly = true)
    public ApiConfig getApiConfig(Long id) {
        return apiConfigRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("API Config not found"));
    }

    private void updateNextExecutionTime(ApiConfig apiConfig) {
        LocalDateTime now = LocalDateTime.now();
        long intervalInMinutes = parseInterval(apiConfig.getScheduleInterval());
        apiConfig.setLastExecutionTime(now);
        apiConfig.setNextExecutionTime(now.plusMinutes(intervalInMinutes));
        apiConfigRepository.save(apiConfig);
    }

    private void validateApiConfig(ApiConfig apiConfig) {
        if (apiConfig.getName() == null || apiConfig.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("API name is required");
        }
        if (apiConfig.getUrl() == null || apiConfig.getUrl().trim().isEmpty()) {
            throw new IllegalArgumentException("API URL is required");
        }
        if (apiConfig.getHttpMethod() == null || apiConfig.getHttpMethod().trim().isEmpty()) {
            throw new IllegalArgumentException("HTTP method is required");
        }
        if (apiConfig.getScheduleInterval() == null || apiConfig.getScheduleInterval().trim().isEmpty()) {
            throw new IllegalArgumentException("Schedule interval is required");
        }
    }

    private long parseInterval(String interval) {
        try {
            String[] parts = interval.split(" ");
            long amount = Long.parseLong(parts[0]);
            TimeUnit unit = TimeUnit.valueOf(parts[1].toUpperCase());
            return TimeUnit.MINUTES.convert(amount, unit);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid interval format. Use format: '5 MINUTES' or '1 HOURS'");
        }
    }
}
