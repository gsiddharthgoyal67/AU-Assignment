package com.customApiScheduler.service;

import com.customApiScheduler.model.ApiConfig;
import com.customApiScheduler.model.ApiExecutionLog;
import com.customApiScheduler.repository.ApiExecutionLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApiExecutionService {
    private final ApiExecutionLogRepository executionLogRepository;
    private final CacheService cacheService;
    private final RestTemplate restTemplate = new RestTemplate();

    @Transactional
    public void executeApi(ApiConfig apiConfig) {
        long startTime = System.currentTimeMillis();
        ApiExecutionLog executionLog = new ApiExecutionLog();
        executionLog.setApiConfig(apiConfig);
        executionLog.setExecutionTime(LocalDateTime.now());

        try {
            // Check cache first
            String cacheKey = cacheService.generateCacheKey(apiConfig.getId());
            Optional<Object> cachedResponse = Optional.ofNullable(cacheService.getCachedApiResponse(cacheKey));

            if (cachedResponse.isPresent()) {
                log.info("Using cached response for API: {}", apiConfig.getName());
                executionLog.setSuccessful(true);
                executionLog.setResponseBody("Using cached response");
                executionLog.setHttpStatusCode(200);
            } else {
                ResponseEntity<String> response = executeHttpRequest(apiConfig);
                executionLog.setSuccessful(response.getStatusCode().is2xxSuccessful());
                executionLog.setHttpStatusCode(response.getStatusCodeValue());
                executionLog.setResponseBody(response.getBody());

                // Cache successful responses
                if (response.getStatusCode().is2xxSuccessful()) {
                    cacheService.cacheApiResponse(cacheKey, response.getBody(), 300); // Cache for 5 minutes
                }
            }
        } catch (Exception e) {
            log.error("Error executing API {}: {}", apiConfig.getName(), e.getMessage());
            executionLog.setSuccessful(false);
            executionLog.setErrorMessage(e.getMessage());
        } finally {
            executionLog.setResponseTime(System.currentTimeMillis() - startTime);
            executionLogRepository.save(executionLog);
        }
    }

    private ResponseEntity<String> executeHttpRequest(ApiConfig apiConfig) {
        HttpHeaders headers = createHeaders(apiConfig);
        HttpEntity<String> entity = new HttpEntity<>(apiConfig.getRequestBody(), headers);

        return restTemplate.exchange(
                apiConfig.getUrl(),
                HttpMethod.valueOf(apiConfig.getHttpMethod()),
                entity,
                String.class
        );
    }

    private HttpHeaders createHeaders(ApiConfig apiConfig) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        if (apiConfig.getRequestHeaders() != null && !apiConfig.getRequestHeaders().isEmpty()) {
            // Parse and add custom headers
            // Note: In a real application, you'd want to properly parse the headers string
            headers.add("Custom-Header", apiConfig.getRequestHeaders());
        }

        return headers;
    }

    @Transactional(readOnly = true)
    public ApiExecutionLog getLastExecution(Long apiConfigId) {
        return executionLogRepository.findByApiConfigIdOrderByExecutionTimeDesc(apiConfigId)
                .stream()
                .findFirst()
                .orElse(null);
    }
}