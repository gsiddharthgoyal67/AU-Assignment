package com.customApiScheduler.controller;


import com.customApiScheduler.model.ApiConfig;
import com.customApiScheduler.model.ApiExecutionLog;
import com.customApiScheduler.service.ApiExecutionService;
import com.customApiScheduler.service.ApiSchedulerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/scheduler")
@RequiredArgsConstructor
public class ApiSchedulerController {
    private final ApiSchedulerService schedulerService;
    private final ApiExecutionService executionService;

    @PostMapping("/configs")
    public ResponseEntity<ApiConfig> createApiConfig(@RequestBody ApiConfig apiConfig) {
        return ResponseEntity.ok(schedulerService.createApiConfig(apiConfig));
    }

    @PutMapping("/configs/{id}")
    public ResponseEntity<ApiConfig> updateApiConfig(@PathVariable Long id, @RequestBody ApiConfig apiConfig) {
        return ResponseEntity.ok(schedulerService.updateApiConfig(id, apiConfig));
    }

    @DeleteMapping("/configs/{id}")
    public ResponseEntity<Void> deleteApiConfig(@PathVariable Long id) {
        schedulerService.deleteApiConfig(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/configs")
    public ResponseEntity<List<ApiConfig>> getAllApiConfigs() {
        return ResponseEntity.ok(schedulerService.getAllApiConfigs());
    }

    @GetMapping("/configs/{id}")
    public ResponseEntity<ApiConfig> getApiConfig(@PathVariable Long id) {
        return ResponseEntity.ok(schedulerService.getApiConfig(id));
    }

    @PostMapping("/configs/{id}/execute")
    public ResponseEntity<Void> executeApiManually(@PathVariable Long id) {
        ApiConfig apiConfig = schedulerService.getApiConfig(id);
        executionService.executeApi(apiConfig);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/configs/{id}/last-execution")
    public ResponseEntity<ApiExecutionLog> getLastExecution(@PathVariable Long id) {
        ApiExecutionLog log = executionService.getLastExecution(id);
        return log != null ? ResponseEntity.ok(log) : ResponseEntity.notFound().build();
    }
}