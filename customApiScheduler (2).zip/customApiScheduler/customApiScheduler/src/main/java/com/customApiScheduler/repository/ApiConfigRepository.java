package com.customApiScheduler.repository;


import com.customApiScheduler.model.ApiConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.LocalDateTime;
import java.util.List;

public interface ApiConfigRepository extends JpaRepository<ApiConfig, Long> {
    @Query("SELECT a FROM ApiConfig a WHERE a.active = true AND a.nextExecutionTime <= :now")
    List<ApiConfig> findApisDueForExecution(LocalDateTime now);

    List<ApiConfig> findByActive(boolean active);
}