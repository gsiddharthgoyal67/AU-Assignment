package com.customApiScheduler.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
public class CacheService {
    private final RedisTemplate<String, Object> redisTemplate;

    public void cacheApiResponse(String key, Object value, long timeoutInSeconds) {
        redisTemplate.opsForValue().set(key, value, timeoutInSeconds, TimeUnit.SECONDS);
    }

    public Object getCachedApiResponse(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    public void invalidateCache(String key) {
        redisTemplate.delete(key);
    }

    public String generateCacheKey(Long apiConfigId) {
        return "api_response:" + apiConfigId;
    }
}