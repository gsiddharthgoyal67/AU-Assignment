package com.customApiScheduler.model;

import lombok.Data;
import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "api_execution_logs")
public class ApiExecutionLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "api_config_id", nullable = false)
    private ApiConfig apiConfig;

    @Column(nullable = false)
    private LocalDateTime executionTime;

    @Column(nullable = false)
    private boolean successful;

    private Long responseTime;

    @Column(length = 1000)
    private String errorMessage;

    private int httpStatusCode;

    @Column(length = 1000)
    private String responseBody;
}