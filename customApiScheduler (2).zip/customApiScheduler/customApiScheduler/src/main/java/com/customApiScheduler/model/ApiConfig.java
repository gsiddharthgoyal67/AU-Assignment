package com.customApiScheduler.model;

import lombok.Data;
import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "api_configs")
public class ApiConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String url;

    @Column(nullable = false)
    private String httpMethod;

    @Column(nullable = false)
    private String scheduleInterval;

    private String requestHeaders;

    private String requestBody;

    private LocalDateTime lastExecutionTime;

    private LocalDateTime nextExecutionTime;

    private boolean active = true;

    @PrePersist
    public void prePersist() {
        if (nextExecutionTime == null) {
            nextExecutionTime = LocalDateTime.now();
        }
    }
}

