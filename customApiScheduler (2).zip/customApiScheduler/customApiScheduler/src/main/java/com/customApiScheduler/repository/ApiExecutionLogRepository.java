package com.customApiScheduler.repository;

import com.customApiScheduler.model.ApiExecutionLog;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ApiExecutionLogRepository extends JpaRepository<ApiExecutionLog, Long> {
    List<ApiExecutionLog> findByApiConfigIdOrderByExecutionTimeDesc(Long apiConfigId);

    List<ApiExecutionLog> findBySuccessfulFalseAndApiConfigId(Long apiConfigId);
}
